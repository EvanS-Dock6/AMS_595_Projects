#include <iostream>
#include "Conditional.h"
using namespace std;
// implement standard protocals
int main(){

    //int num; //define a variable 

    cout << "Enter a number: ";
    cin >> num; // takes a user integer input

    switch (num){ //uses a switch function to account for multiple scenarios

        case -1: //if the number is -1 do this 
        cout << "negative one" << endl; 
        break;
        case 0: //if the number is 0 do this 
        cout << "zero" << endl;
        break;
        case 1: //if the number is 1 do this
        cout << "positive one" << endl;
        break;
        default://if any other number, print this
        cout << "random number" << endl;

    }
}