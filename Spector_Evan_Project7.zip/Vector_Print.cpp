#include <iostream>
#include <vector>
#include "Vector_Print.h"
using namespace std;
// implement standard protocals
void print_vector(std::vector<int> v)
{   
     // Your implementation
    for (int num : v) //print out its contents
        cout << num << ' '; 
}