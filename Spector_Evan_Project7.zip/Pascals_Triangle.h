#ifndef PASCALS_TRIANGLE_H
#define PASCALS_TRIANGLE_H
#include <iostream>
using namespace std;
int pascalValue(int row, int col);
void PascalsTriangle(int n, int row);
#endif