#ifndef PRIME_FACTOR_H
#define PRIME_FACTOR_H
#include <vector>
std::vector<int> prime_factorize(int n);
void test_prime_factorize();
#endif
