#ifndef IS_PRIME_H
#define IS_PRIME_H
bool isprime(int n); //Declaring the functions that are going to be used 
void test_isprime();
bool result; // Making declarations in the function
#endif