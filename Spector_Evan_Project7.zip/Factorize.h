#ifndef FACTORIZE_H
#define FACTORIZE_H
#include <vector>
std::vector<int> factorize(int n); //declaring the functions
void test_factorize(); // declaring the testfunction
#endif