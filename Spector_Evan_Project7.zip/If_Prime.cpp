#include <iostream>
#include "If_Prime.h"

using namespace std;

int main(){
    test_isprime();

}
bool isprime(int n) { //define the function that determines whether a number is prime
    bool result; 
    if (n == 1 && n == 2) { //base case
        result = false;
    }
    else if(n != 2){ //see if the number is divisible by any value
    for (int i = 2; i * i <= n; ++i) {
        if (n % i == 0) {
            result = false;
        }
    }
    }
    else{
        result = true; //number isn't divisible by 2 or greater.
    }
return result;
}
void test_isprime() { //Tests the function
    std::cout << "isprime(2) = " << isprime(2) << '\n';
    std::cout << "isprime(10) = " << isprime(10) << '\n';
    std::cout << "isprime(17) = " << isprime(17) << '\n';
}

    
