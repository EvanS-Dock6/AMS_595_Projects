#include <iostream>
#include "Pascals_Triangle.h"
using namespace std;

// Function to calculate the value at a specific position (row, col) in Pascal's Triangle
int pascalValue(int row, int col) {
    // Base case: If the column is 0 or the column equals the row, return 1
    if (col == 0 || col == row) {
        return 1;
    }
    // Recursive case: sum of the two values from the row above
    return pascalValue(row - 1, col - 1) + pascalValue(row - 1, col);
}

// Function to print the first 'n' rows of Pascal's Triangle
void PascalsTriangle(int n, int row = 0) {
    // Base case: If row is equal to n, stop the recursion
    if (row == n) {
        return;
    }
    
    // Print each value in the current row using pascalValue
    for (int col = 0; col <= row; ++col) {
        cout << pascalValue(row, col) << " ";
    }
    cout << endl;
    
    // Recursively print the next row
    PascalsTriangle(n, row + 1);
}

int main() {
    int n;
    cout << "Enter the number of rows for Pascal's Triangle: ";
    cin >> n;

    // Print the first n rows of Pascal's Triangle
    PascalsTriangle(n);
    
    return 0;
}
