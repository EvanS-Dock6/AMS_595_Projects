//Declaration of variables 
#ifndef WHILE_LOOP_H
#define WHILE_LOOP_H
int num1; 
int num2;
int fib;
#endif