#include <iostream>
#include "While_Loop.h"
using namespace std;

int main()
{
    num1 = 1;//Declaring the starting values
    num2 = 2;
    cout << num1;//Printing these values first in the list
    cout << ',';
    cout << num2;
    cout << ',';
    while(fib < 4000000)
    { 
        fib = num1 + num2;//Initiating the fibonnaci sequence
        if (fib > 4000000){ //stops the sequence when a value exceeds 4000000
            break;
        }
        cout << fib; 
        cout << ',';
        num1 = num2;
        num2 = fib;
    }
}