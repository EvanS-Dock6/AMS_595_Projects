#include <iostream>
#include <vector>
#include "Factorize.h"
#include "Vector_Print.h"

using namespace std;

int main(){
    //calling the test function
    test_factorize();

}

std::vector<int> factorize(int n) //defining the factorize function 
{
    std::vector<int> answer;
    for (int i = 1; i <= n; ++i) { //if n is divisible by any of the numbers
        if (n % i == 0) {
            answer.push_back(i); // add that value to the vector
        }
    }
    return answer; //returns a a vector with the factors
}
//defining the function to test the factors
void test_factorize() {
    print_vector(factorize(2)); //this function calls the print vector function made earlier
    cout << '\n';
    print_vector(factorize(72));
    cout << '\n';
    print_vector(factorize(196));
}
