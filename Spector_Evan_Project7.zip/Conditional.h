#ifndef CONDITIONAL_H
#define CONDITIONAL_H
int num; //Making variable declarations
#endif