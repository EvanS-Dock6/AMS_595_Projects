#include <iostream>
#include <vector>
#include "Prime_Factor.h"
#include "Vector_Print.h"

using namespace std;

int main(){
    test_prime_factorize();
}
std::vector<int> prime_factorize(int n){
    std::vector<int> answer;
// Check for number of 2s that divide the number
    while (n % 2 == 0) {
        answer.push_back(2);
        n /= 2;
    }

    // Check for odd factors from 3 upwards
    for (int i = 3; i * i <= n; i += 2) {
        while (n % i == 0) {
            answer.push_back(i);
            n /= i;
        }
    }

    // If the remaining number is greater than 2, it is prime
    if (n > 2) {
        answer.push_back(n);
    }

    return answer;
}
    

void test_prime_factorize() { //Function tests the prime factors to be used
    print_vector(prime_factorize(2));
    cout << '\n';
    print_vector(prime_factorize(72));
    cout << '\n';
    print_vector(prime_factorize(196));
}