#ifndef VECTOR_PRINT_H
#define VECTOR_PRINT_H
#include <vector>
using namespace std;
void print_vector(std::vector<int> v); //declaring the function
#endif